﻿using SPR.HorseTrack.Entities;
using System;
using System.Collections.Generic;
namespace SPR.HorseTrack.Services.Common
{
    public static class CommonMethods
    {
        static List<Horse> horseList = new List<Horse>();
        public static void DisplayMessage(string msg)
        {
            Console.WriteLine(msg);
        }  

        private static Horse PopulateHorse(int id, string name, int odds, bool didWin)
        {
            Horse horse = new Horse
            {
                Id = id,
                Name = name,
                Odds = odds,
                DidWin = didWin
            };
            return horse;
        }

        internal static List<Horse> GetAllHorses()
        {
            Horse horse = PopulateHorse(1, "That Darn Gray Cat", 5, true);
            horseList.Add(horse);
            horse = PopulateHorse(2, "Fort Utopia", 10, false);
            horseList.Add(horse);
            horse = PopulateHorse(3, "Count Sheep", 9, false);
            horseList.Add(horse);
            horse = PopulateHorse(4, "Ms Traitour", 4, false);
            horseList.Add(horse);
            horse = PopulateHorse(5, "Pa Kettle", 5, false);
            horseList.Add(horse);
            horse = PopulateHorse(6, "Gin Stinger", 6, false);
            horseList.Add(horse);
            return horseList;
        }
    }
}
