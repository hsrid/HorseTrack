﻿using SPR.HorseTrack.Entities;
using SPR.HorseTrack.Services.Interfaces;
using System;
using System.Text;

namespace SPR.HorseTrack.Services
{
    public class Inventory : IInventory
    {
        Currency currency = PopulateCurrency(10, 10, 10, 10, 10);
        //totalAvailAmount (currency values * available count) = (OneCount * 1) + (FiveCount * 5) + (TenCount * 10) + (TwentyCount * 20) + (HunderedCount * 100)
        private static int totalAvailAmount;
        //BetNumber * Odds
        private static int payout;

        /// <summary>
        /// Method reload the inventory
        /// </summary>
        public void Reload()
        {
            currency = PopulateCurrency(10, 10, 10, 10, 10);
        }

        /// <summary>
        /// Method to display the inventory
        /// </summary>
        public void DisplayInventory()
        {
            if (null != currency)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("Inventory:\n");
                sb.Append("$1," + currency.OneCount + "\n");
                sb.Append("$5," + currency.FiveCount + "\n");
                sb.Append("$10 " + currency.TenCount + "\n");
                sb.Append("$20," + currency.TwentyCount + "\n");
                sb.Append("$100," + currency.HunderedCount + "\n");
                Console.WriteLine(sb.ToString());
            }
        }

        /// <summary>
        /// Method to populate the currency
        /// </summary>
        /// <param name="oneCount"></param>
        /// <param name="fiveCount"></param>
        /// <param name="twentyCount"></param>
        /// <param name="tenCount"></param>
        /// <param name="hunderedCount"></param>
        /// <returns>Currency values</returns>
        private static Currency PopulateCurrency(int oneCount, int fiveCount, int twentyCount, int tenCount, int hunderedCount)
        {
            Currency curr = new Currency
            {
                OneCount = oneCount,
                FiveCount = fiveCount,
                TwentyCount = twentyCount,
                TenCount = tenCount,
                HunderedCount = hunderedCount
            };
            return curr;
        }

        /// <summary>
        /// Method to get the change for each currency amount passed in        /
        /// </summary>
        /// <param name="currency"></param>
        /// <returns></returns>
        private int GetChange(int currency)
        {
            //payout = BetNumber * odds
            int result = payout / currency;
            totalAvailAmount = totalAvailAmount - (result * currency);
            payout = payout - (result * currency);
            return result;
        }

        /// <summary>
        /// Method to Display Dispensing Information
        /// </summary>
        /// <param name="ipayout">input payout</param>
        /// <returns>dispensing message or empty string</returns>
        public string DisplayDispensingInfo(int ipayout)
        {
            //check for valid payout
            if (ipayout > 0)
            {
                totalAvailAmount = currency.TotalCash();
                payout = ipayout;
                if (payout < totalAvailAmount)
                {
                    int hundred = GetChange(100);
                    int twenty = GetChange(20);
                    int ten = GetChange(10);
                    int five = GetChange(5);
                    int one = GetChange(1);
                    if (!SetInventory(currency, hundred, twenty, ten, five, one))
                    {
                        return string.Empty;
                    }
                    StringBuilder sb = new StringBuilder();
                    sb.Append("Dispensing:\n");
                    sb.Append("$1," + 0 + "\n");
                    sb.Append("$5," + five + "\n");
                    sb.Append("$10," + ten + "\n");
                    sb.Append("$20," + twenty + "\n");
                    sb.Append("$100," + hundred);
                    return sb.ToString();
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Set the counts of the currency provided
        /// </summary>
        /// <param name="currency"></param>
        /// <param name="hundred"></param>
        /// <param name="twenty"></param>
        /// <param name="ten"></param>
        /// <param name="five"></param>
        /// <param name="one"></param>
        /// <returns>bool true or false</returns>
        private bool SetInventory(Currency currency, int hundred, int twenty, int ten, int five, int one)
        {
            int oldHundred = currency.HunderedCount;
            int oldTwenty = currency.TwentyCount;
            int oldTen = currency.TenCount;
            int oldFive = currency.FiveCount;
            int oldOne = currency.OneCount;

            bool success = true;

            if (oldHundred >= hundred)
            {
                currency.HunderedCount = (oldHundred - hundred);
            }
            else
            {
                success = false;
            }
            if (oldTwenty >= twenty)
            {
                currency.TwentyCount = (oldTwenty - twenty);
            }
            else
            {
                success = false;
            }
            if (oldTen >= ten)
            {
                currency.TenCount = (oldTen - ten);
            }
            else
            {
                success = false;
            }
            if (oldFive >= five)
            {
                currency.FiveCount = (oldFive - five);
            }
            else
            {
                success = false;
            }
            if (oldOne >= one)
            {
                currency.OneCount = (oldOne - one);
            }
            else
            {
                success = false;
            }

            if (success == false)
            {
                currency.HunderedCount = oldHundred;
                currency.TwentyCount = oldTwenty;
                currency.TenCount = oldTen;
                currency.FiveCount = oldFive;
                currency.OneCount = oldOne;
            }
            return success;
        }
    }
}
