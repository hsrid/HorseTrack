﻿using SPR.HorseTrack.Entities;

namespace SPR.HorseTrack.Services.Interfaces
{
    public interface IInventory
    {
        void Reload();
        void DisplayInventory();
        string DisplayDispensingInfo(int payout);
    }
}
