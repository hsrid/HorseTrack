﻿using SPR.HorseTrack.Entities;

namespace SPR.HorseTrack.Services.Interfaces
{
    public interface IHorseService
    {
        int GetWinnerHorse();
        Horse GetHorse(int horseId);
        void SetWinnerHorse(int horseId);
        void DisplayHorses();
        HorseBet SetBet(Horse horse, int betNumber);
        void ValidateInput(string input);
    }
}
