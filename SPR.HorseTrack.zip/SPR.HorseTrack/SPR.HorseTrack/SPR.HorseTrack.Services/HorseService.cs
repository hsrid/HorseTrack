﻿using SPR.HorseTrack.Entities;
using SPR.HorseTrack.Services.Common;
using SPR.HorseTrack.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPR.HorseTrack.Services
{
    public class HorseService : IHorseService
    {
        /// <summary>
        /// IInventory instance
        /// </summary>
        private static IInventory invService;
        /// <summary>
        /// Horse List
        /// </summary>
        static List<Horse> horseList = new List<Horse>();

        /// <summary>
        /// Class constructor 
        /// </summary>
        /// <param name="inSer">IInventory instance</param>
        public HorseService(IInventory inSer)
        {
            invService = inSer;
        }

        /// <summary>
        /// Method to get the winner horse
        /// </summary>
        /// <returns>int : winner horse id</returns>
        public int GetWinnerHorse()
        {
            if (horseList.Count == 0)
            {
                horseList = CommonMethods.GetAllHorses();
            }
            Horse horse = horseList.Single(a => a.DidWin);
            return horse.Id;
        }

        /// <summary>
        /// Method to set the winner horse
        /// </summary>
        /// <param name="horseId">input horse id</param>
        public void SetWinnerHorse(int horseId)
        {
            if (horseId > 0)
            {
                if (horseList.Count == 0)
                {
                    horseList = CommonMethods.GetAllHorses();
                }

                bool hasHorse = horseList.Any(horse => horse.Id == horseId);

                if (hasHorse)
                {
                    //set the value of didwin = false for all the horses
                    horseList.Select(c => { c.DidWin = false; return c; }).ToList();
                    //set the value of didwin = true for the horse that won
                    horseList.Where(c => c.Id == horseId).FirstOrDefault().DidWin = true;
                }
                else
                {
                    CommonMethods.DisplayMessage("Invalid Horse Number: " + horseId);
                }
            }
            else
            {
                CommonMethods.DisplayMessage("Invalid Horse Number: " + horseId);
            }
        }

        /// <summary>
        /// Method to display the horse in the UI
        /// </summary>
        public void DisplayHorses()
        {
            if (horseList.Count == 0)
            {
                horseList = CommonMethods.GetAllHorses();
            }
            StringBuilder sb = new StringBuilder();
            sb.Append("Horses:\n");
            foreach (Horse horse in horseList)
            {
                sb.Append(horse.Id + ", " + horse.Name + ", " + horse.Odds + ", ");
                sb.Append(horse.DidWin ? "Won" + "\n" : "Lost" + "\n");
            }
            Console.WriteLine(sb.ToString());
        }

        /// <summary>
        /// Method to set the Horse bet details
        /// </summary>
        /// <param name="horse">Horse</param>
        /// <param name="betNumber">int bet number</param>
        /// <returns>HorseBet details</returns>
        public HorseBet SetBet(Horse horse, int betNumber)
        {
            HorseBet horseBet = new HorseBet
            {
                Horsedetails = horse,
                BetNumber = betNumber
            };
            return horseBet;
        }

        /// <summary>
        /// Get Horse details based on horse id passed in
        /// </summary>
        /// <param name="horseId"></param>
        /// <returns></returns>
        public Horse GetHorse(int horseId)
        {
            Horse horse = null;
            if (horseId > 0)
            {
                horse = horseList.Where(c => c.Id == horseId).FirstOrDefault();
            }
            return horse;
        }

        /// <summary>
        /// Check if the horse number passed in is valid
        /// </summary>
        /// <param name="horseNo">horse number int</param>
        /// <returns>true/false</returns>
        private static bool CheckIfValidNumber(int horseNo)
        {
            return horseNo >= 1 && horseNo <= 7 ? true : false;
        }

        /// <summary>
        /// Method to check if the input command has numbers
        /// </summary>
        /// <param name="inputCommand">input commands provided by the user</param>
        /// <returns>true : input has numbers else return false</returns>
        private static bool CheckIfNumbersExists(string inputCommand)
        {
            bool hasNumbers = inputCommand.Any(char.IsDigit);
            return hasNumbers;
        }

        /// <summary>
        /// Method to handle Reload and Quit operation
        /// </summary>
        /// <param name="inputCommand">input commands provided by the user</param>
        private void HandleQuitandReload(string inputCommand)
        {
            switch (inputCommand.ToLower())
            {
                case "r":
                    //TODO: Code to reload the currency.
                    invService.DisplayInventory();
                    DisplayHorses();
                    break;
                case "q":
                    Environment.Exit(0);
                    break;
            }
        }

        /// <summary>
        /// Method to validate and perform expected operation based on the input commands provided by the user
        /// </summary>
        /// <param name="inputCommand">input commands provided by the user</param>
        public void ValidateInput(string inputCommand)
        {
            if (!string.IsNullOrWhiteSpace(inputCommand))
            {
                int inputLength = inputCommand.Length;
                if (inputLength == 0)
                {
                    CommonMethods.DisplayMessage("Invalid Command: " + inputCommand);
                    return;
                }
                //code to handle reload and quit
                if (inputLength == 1)
                {
                    HandleQuitandReload(inputCommand);
                    return;
                }
                //code to check whether input command is to process the bet or to set the winner horse
                if (inputLength >= 2 && CheckIfNumbersExists(inputCommand))
                {
                    string[] firstChar = inputCommand.Split(' ');
                    int horseNumber;
                    //if the first char entered is a number
                    if (firstChar != null && firstChar.Length > 1)
                    {
                        if (int.TryParse(firstChar[0], out horseNumber))
                        {
                            if (!CheckIfValidNumber(horseNumber))
                            {
                                CommonMethods.DisplayMessage("Invalid Horse Number: " + horseNumber);
                            }
                            else
                            {
                                if (firstChar.Length > 1)
                                {
                                    string betNumber = firstChar[1].Trim();
                                    int ibet;
                                    if (int.TryParse(betNumber, out ibet) && ibet > 0)
                                    {
                                        HandleValidBet(horseNumber, ibet);
                                    }
                                    else
                                    {
                                        CommonMethods.DisplayMessage("Invalid Bet: " + betNumber);
                                    }
                                }
                            }
                        }
                        else
                        {
                            //string lastChar = inputCommand[inputCommand.Length - 1].ToString();
                            string lastChar = firstChar[1].Trim();
                            int lastNumber;
                            if (firstChar[0].ToLower().Equals("w") && int.TryParse(lastChar, out lastNumber))
                            {
                                //code to set the winner horse
                                if (horseList.Count == 0)
                                {
                                    horseList = CommonMethods.GetAllHorses();
                                }
                                SetWinnerHorse(lastNumber);
                                invService.DisplayInventory();
                                DisplayHorses();
                            }
                            else
                            {
                                CommonMethods.DisplayMessage("Invalid Command: " + inputCommand);
                            }
                        }
                    }
                }
                else
                {
                    CommonMethods.DisplayMessage("Invalid Command: " + inputCommand);
                }
            }
            else
            {
                CommonMethods.DisplayMessage("Invalid Command: " + inputCommand);
            }
        }

        /// <summary>
        /// Method to handle invalid bet values
        /// </summary>
        /// <param name="horseNumber">horse number</param>
        /// <param name="ibet">bet value</param>
        private void HandleValidBet(int horseNumber, int ibet)
        {
            int winner = GetWinnerHorse();
            Horse selHorse = GetHorse(horseNumber);
            HorseBet bet = null;
            if (selHorse != null)
            {
                bet = SetBet(selHorse, ibet);
            }
            if (horseNumber == winner)
            {
                Horse winnerHorse = GetHorse(winner);
                StringBuilder sb = new StringBuilder("Payout: " + winnerHorse.Name + ", $" + winnerHorse.Odds * bet.BetNumber);

                string result = invService.DisplayDispensingInfo(bet.BetNumber * winnerHorse.Odds);

                if (!string.IsNullOrWhiteSpace(result))
                {
                    CommonMethods.DisplayMessage(sb.ToString());
                    CommonMethods.DisplayMessage(result);
                }
                else
                {
                    //insufficient funds message                           
                    CommonMethods.DisplayMessage("Insufficient Funds: " + winnerHorse.Odds * bet.BetNumber);
                }
            }
            else
            {
                // if loser
                Horse loserHorse = GetHorse(bet.Horsedetails.Id);
                CommonMethods.DisplayMessage("No Payout: " + loserHorse.Name);
            }
        }
    }
}
