﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SPR.HorseTrack.Entities;
using SPR.HorseTrack.Services;
using SPR.HorseTrack.Services.Interfaces;

namespace SPR.HorseTrack.Test
{
    [TestClass]
    public class InventoryTest
    {
        private IInventory invService;

        /// <summary>
        /// Initializes the test method
        /// </summary>
        [TestInitialize]
        public void InitializeTest()
        {
            invService = new Inventory();           
        }


       /// <summary>
       /// test method to check if the inventory is displayed appropriately
       /// </summary>
       /**  Output:	Inventory:
            $1,10
            $5,10
            $10 10
            $20,10
            $100,10
        **/
        [TestMethod]
        public void DisplayInventoryTest()
        {
            invService.DisplayInventory();
        }


        /// <summary>
        /// Method to check if the input inventory is returned when payout is 0
        /// </summary>        
        [TestMethod]
        public void DisplayDispensingForZeroPayoutTest()
        {
            int payout = 0;
            string result = invService.DisplayDispensingInfo(payout);
            Assert.AreEqual(string.Empty, result);
        }

        /// <summary>
        /// Method to check if the input inventory is return when payout is 0
        /// </summary>        
        [TestMethod]
        public void DisplayDispensingForNegativePayoutTest()
        {
            int payout = -10;
            string result = invService.DisplayDispensingInfo(payout);
            Assert.AreEqual(string.Empty, result);
        }

        /// <summary>
        /// Method to check if the input inventory is returned appropriately when payout > balance
        /// </summary>        
        [TestMethod]
        public void DisplayDispensingForMorePayoutTest()
        {
            int payout = 2055;
            string result = invService.DisplayDispensingInfo(payout);
            Assert.AreEqual(string.Empty, result);
        }

        /// <summary>
        /// Method to check if the input inventory is returned appropriately when payout < balance
        /// </summary>        
        [TestMethod]
        public void DisplayDispensingForLessPayoutTest()
        {
            int payout = 255;
            string result = invService.DisplayDispensingInfo(payout);
            Assert.AreEqual("Dispensing:\n$1,0\n$5,1\n$10,1\n$20,2\n$100,2", result);
        } 
    }
}
