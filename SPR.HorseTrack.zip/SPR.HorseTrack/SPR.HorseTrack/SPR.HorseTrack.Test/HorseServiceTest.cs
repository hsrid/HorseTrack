﻿using System;
using SPR.HorseTrack.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SPR.HorseTrack.Services.Interfaces;

namespace SPR.HorseTrack.Test
{   
    
    [TestClass]
    public class HorseServiceTest
    {
        private IInventory invService;
        private IHorseService service;

        /// <summary>
        /// Initializes the test method
        /// </summary>
        [TestInitialize]
        public void InitializeTest()
        {
            invService = new Inventory();
            service = new HorseService(invService);
        }

        /// <summary>
        /// Test method to check if horse list is displayed properly
        /// Expected Output :    
        /*** Horses:
          1, That Darn Gray Cat, 5, Won
          2, Fort Utopia, 10, Lost
          3, Count Sheep, 9, Lost
          4, Ms Traitour, 4, Lost
          5, Pa Kettle, 5, Lost
          6, Gin Stinger, 6, Lost
         ***/
        /// </summary>
        [TestMethod]
        public void DisplayHorsesTest()
        { 
            service.DisplayHorses();             
        }        

        /// <summary>
        /// Get the winner horse number
        /// </summary>
        [TestMethod]
        public void GetWinnerHorseTest()
        {
            int winnerHorse = service.GetWinnerHorse();
            Assert.AreEqual(winnerHorse,1);
        }
        
        /// <summary>
        /// set horse 2 as winner horse
        /// </summary>
        [TestMethod]
        public void SetWinnerHorsePositiveValueTest()
        {
            service.SetWinnerHorse(2);
        }


        /// <summary>
        /// Test to pass negative value to winner horse
        /// </summary>
        [TestMethod]
        public void SetWinnerHorseNegativeValueTest()
        {
            service.SetWinnerHorse(-2);
        }

        /// <summary>
        /// Test to check empty string as input
        /// Expected Output :    
        /** Invalid Command: **/
        /// </summary>
        [TestMethod]
        public void ValidateInputEmptyString()
        {
            string command = string.Empty;
            service.ValidateInput(command);
        }

        /// <summary>
        /// Test to check empty string as null
        /// Expected Output :    
        /** Invalid Command: **/
        [TestMethod]
        public void ValidateInputNull()
        {
            string command = null;
            service.ValidateInput(command);
        }

        /// <summary>
        /// Test to check empty string as blank space
        /// Expected Output :    
        /** Invalid Command: **/
        [TestMethod]
        public void ValidateInputBlankSpace()
        {  
            string command = "  ";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Test to check empty string as invalid characters
        /// Expected Output :    
        /** Invalid Command: foo **/
        [TestMethod]
        public void ValidateInputSomeChars()
        {
            string command = "foo";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Test to check empty string as bet value as special characters
        /// Expected Output :    
        /** Invalid Command: $$$ **/
        [TestMethod]
        public void ValidateInputSpecialChars()
        {
            string command = "1 $$$";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Test to check payout displayed is valid for passed in value
        /// Expected Output :    
        /** 
            Payout: That Darn Gray Cat, $275
            Dispensing:
            $1,0
            $5,1
            $10,1
            $20,3
            $100,2
        **/
        [TestMethod]
        public void ValidatePayout()
        {
            string command = "1 55";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Test to check payout displayed is valid for passed in value
        /// Expected Output :    
        /**            	
            Payout: That Darn Gray Cat, $525
            Dispensing:
            $1,0
            $5,1
            $10,0
            $20,1
            $100,5
        **/

        [TestMethod]
        public void ValidatePayoutDifferntNumbers()
        {
            string command = "1 105";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Test to check no payout displayed when entered horse is not winner
        /// Expected Output :    
        /**           	
          No Payout: Fort Utopia
        **/
        [TestMethod]
        public void ValidateNoPayout()
        {
            string command = "2 55";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Test to check no payout displayed when entered horse is not in the list of horses
        /// Expected Output : Invalid Horse Number: 10
        
        [TestMethod]
        public void ValidateNoPayoutInvalidHorseNumber()
        {
            string command = "10 55";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Test to Insufficient Funds when payout (BetNumber * winnerHorse = 5 * 555) is less than total balance (1360)
        /// Expected Output : Insufficient Funds: 2775
        [TestMethod]
        public void ValidateInsufficientFunds()
        {
            string command = "1 555";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Test if the 3rd horse is set as winner horse when command has upper case 'W'
        /// Expected Output :
        /***    	
            Inventory:
            $1,10
            $5,10
            $10 10
            $20,10
            $100,10

            Horses:
            1, That Darn Gray Cat, 5, Lost
            2, Fort Utopia, 10, Lost
            3, Count Sheep, 9, Won
            4, Ms Traitour, 4, Lost
            5, Pa Kettle, 5, Lost
            6, Gin Stinger, 6, Lost
        ***/
        [TestMethod]
        public void ValidateWinnerHorseUpperCase()
        {
            string command = "W 3";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Test if the 3rd horse is set as winner horse when command has lower case 'w'
        /// Expected Output :
        /***    	
            Inventory:
            $1,10
            $5,10
            $10 10
            $20,10
            $100,10

            Horses:
            1, That Darn Gray Cat, 5, Lost
            2, Fort Utopia, 10, Lost
            3, Count Sheep, 9, Won
            4, Ms Traitour, 4, Lost
            5, Pa Kettle, 5, Lost
            6, Gin Stinger, 6, Lost
        ***/
        [TestMethod]
        public void ValidateWinnerHorseLowerCase()
        {
            string command = "w 3";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Test if invalid horse number is passed as winner horse
        /* Output:	Invalid Command: w 19 */
        [TestMethod]
        public void ValidateWinnerInvalidHorseNumber()
        {
            string command = "w 19";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Validate input commands
        /// </summary>
        /* Output:	Invalid Command: x 4 */
        [TestMethod]
        public void ValidateAnotherCharAsInput()
        {
            string command = "x 4";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Validate decimal value as bet number
        /// </summary>
        /* Output:	Invalid Bet: 10.55 */
        [TestMethod]
        public void ValidateDecimalInvalidBets()
        {
            string command = "4 10.55";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Validate negative number as bet number
        /// </summary>
        /* Output:	Invalid Bet: -10*/
        [TestMethod]
        public void ValidateNagtiveInvalidBets()
        {
            string command = "4 -10";
            service.ValidateInput(command);
        }
        
        /// <summary>
        ///  Validate char bet number
        /// </summary>
         /* Output:	Invalid Bet: a */
        [TestMethod]
        public void ValidateCharInvalidBets()
        {
            string command = "1 a";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Validate reload happens with upper case 'R' as input command
        /// </summary>
        /**
            Inventory:
            $1,10
            $5,10
            $10 10
            $20,10
            $100,10

            Horses:
            1, That Darn Gray Cat, 5, Won
            2, Fort Utopia, 10, Lost
            3, Count Sheep, 9, Lost
            4, Ms Traitour, 4, Lost
            5, Pa Kettle, 5, Lost
            6, Gin Stinger, 6, Lost

          **/
        [TestMethod]
        public void ValidateUppecaseReload()
        {
            string command = "R";
            service.ValidateInput(command);
        }

        /// <summary>
        /// Validate reload happens with lower case 'r' as input command
        /// </summary>
        /**
            Inventory:
            $1,10
            $5,10
            $10 10
            $20,10
            $100,10

            Horses:
            1, That Darn Gray Cat, 5, Won
            2, Fort Utopia, 10, Lost
            3, Count Sheep, 9, Lost
            4, Ms Traitour, 4, Lost
            5, Pa Kettle, 5, Lost
            6, Gin Stinger, 6, Lost
          **/
        [TestMethod]
        public void ValidateLowercaseReload()
        {
            string command = "r";
            service.ValidateInput(command);
        }  
    }
}
