﻿using SPR.HorseTrack.Services;
using SPR.HorseTrack.Services.Interfaces;
using System;

namespace SPR.HorseTrack.Host
{
    class Program
    {
        private static IHorseService horseService;
        private static IInventory invService;
        public static void Main(string[] args)
        {
            string inputCommand = string.Empty;
            invService = new Inventory();
            horseService = new HorseService(invService);
            invService.DisplayInventory();
            horseService.DisplayHorses();
            do
            {
                inputCommand = Console.ReadLine();
                if (!string.IsNullOrEmpty(inputCommand))
                {
                    horseService.ValidateInput(inputCommand);
                    invService.DisplayInventory();
                    horseService.DisplayHorses();
                    inputCommand = string.Empty;
                }
            }
            while (true);           
        }
    }
}
