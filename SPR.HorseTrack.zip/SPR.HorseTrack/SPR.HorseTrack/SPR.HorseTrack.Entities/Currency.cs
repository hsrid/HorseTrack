﻿namespace SPR.HorseTrack.Entities
{
    public class Currency
    {
        public int OneCount;
        public int FiveCount;
        public int TenCount;
        public int TwentyCount;
        public int HunderedCount;
        /// <summary>
        /// Method to compute total cash in hand
        /// </summary>
        /// <returns>total cash : int</returns>
        public int TotalCash()
        {
            return (OneCount * 1) + (FiveCount * 5) + (TenCount * 10) + (TwentyCount * 20) + (HunderedCount * 100);
        }    
    }
}
