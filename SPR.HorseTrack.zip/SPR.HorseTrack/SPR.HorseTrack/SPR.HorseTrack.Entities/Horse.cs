﻿namespace SPR.HorseTrack.Entities
{
    public class Horse
    {
        public int Id;
        public string Name;
        public int Odds;
        public bool DidWin;
    }
}
