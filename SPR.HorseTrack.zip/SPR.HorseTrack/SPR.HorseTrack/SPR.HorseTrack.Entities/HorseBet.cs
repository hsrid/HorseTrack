﻿namespace SPR.HorseTrack.Entities
{
    public class HorseBet
    {
        public Horse Horsedetails;
        public int BetNumber;       
    }
}
